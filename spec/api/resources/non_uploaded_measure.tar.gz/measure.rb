class NonUploadedMeasure < OpenStudio::Ruleset::ModelUserScript
  def arguments(model)
    # not a real measure
  end

  def run(model, runner, user_arguments)
    # not a real measure

    super(model, runner, user_arguments)

    true
  end
end

NonUploadedMeasure.new.registerWithApplication
